from pyspark.sql import SparkSession
from pyspark.sql.functions import col, explode, avg

spark = SparkSession.builder.getOrCreate()

data = [(10, [100, 200, 300]), (20, [400, 500, 600]), (30, [700, 800, 900])]
schema = ["cust_id", "purchase_items"]

df = spark.createDataFrame(data, schema)

df.show(truncate=False)
df.printSchema()

df = df\
    .select(col("cust_id"), explode(col("purchase_items")).alias("purchase_items"))\
    .groupby(col("cust_id")).agg(avg(col("purchase_items")).alias("avg_purchase_items"))

df.show()
